import Stripe from "stripe";
import { Resend } from "resend";
import twilio from "twilio";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
const resend = new Resend(process.env.RESEND_API_KEY);

export async function POST(request) {
  try {
    const body = await request.json();

    if (!body.orderItems || body.orderItems.length === 0) {
      return Response.json({ error: "Please add at least one permit to your order." }, { status: 400 });
    }

    if (body.hasQuoteRequired) {
      return Response.json({ error: "One or more selected items requires manual quote confirmation before payment." }, { status: 400 });
    }

    const amountInCents = Math.round(body.estimatedTotal * 100);

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: "Moving Forward Permit Request",
              description: `${body.orderItems.length} permit item(s), ${body.isRushOrder ? "Rush" : "Standard"} processing`,
            },
            unit_amount: amountInCents,
          },
          quantity: 1,
        },
      ],
      customer_email: body.customer?.email || undefined,
      success_url: `${process.env.NEXT_PUBLIC_SITE_URL || "https://movingforwardpermits.com"}/success`,
      cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL || "https://movingforwardpermits.com"}/`,
      metadata: {
        customer_name: body.customer?.contactName || "",
        company_name: body.customer?.companyName || "",
        order_summary: JSON.stringify(body.orderItems).slice(0, 450),
      },
    });

    await resend.emails.send({
      from: "Moving Forward Permits <onboarding@resend.dev>",
      to: process.env.ADMIN_ALERT_EMAIL,
      subject: "New Permit Request Started",
      html: `
        <h2>New Permit Request Started</h2>
        <p><strong>Company:</strong> ${body.customer?.companyName || ""}</p>
        <p><strong>Contact:</strong> ${body.customer?.contactName || ""}</p>
        <p><strong>Phone:</strong> ${body.customer?.phone || ""}</p>
        <p><strong>Email:</strong> ${body.customer?.email || ""}</p>
        <p><strong>Total:</strong> $${body.estimatedTotal}</p>
        <p><strong>Processing:</strong> ${body.isRushOrder ? "Rush" : "Standard"}</p>
        <pre>${JSON.stringify(body.orderItems, null, 2)}</pre>
      `,
    });

    if (process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && process.env.TWILIO_PHONE_NUMBER && process.env.ADMIN_ALERT_PHONE) {
      const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
      await client.messages.create({
        body: `New Moving Forward permit request started. Total: $${body.estimatedTotal}. Check email for details.`,
        from: process.env.TWILIO_PHONE_NUMBER,
        to: process.env.ADMIN_ALERT_PHONE,
      });
    }

    return Response.json({ url: session.url });
  } catch (error) {
    console.error(error);
    return Response.json({ error: error.message || "Server error" }, { status: 500 });
  }
}
