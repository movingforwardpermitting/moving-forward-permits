export default function SuccessPage() {
  return (
    <div className="min-h-screen bg-slate-950 px-6 py-20 text-white">
      <div className="mx-auto max-w-2xl rounded-3xl border border-slate-800 bg-slate-900 p-8">
        <h1 className="text-3xl font-bold">Payment received</h1>
        <p className="mt-4 text-slate-300">
          Thank you. Your permit request has been received and will be reviewed before processing.
        </p>
        <a href="/" className="mt-8 inline-block rounded-2xl bg-amber-400 px-7 py-4 font-semibold text-slate-950">
          Back to home
        </a>
      </div>
    </div>
  );
}
